#include <stdio.h>
#include <stdlib.h>
#include <math.h>  /* para usar o INFINITY */
#include "grafo.h"

void ExibirGrafo (Grafo g)
{
    int i, j;
    system("CLS");
    printf ("Numero de vertices do %s: %i\n", g.digrafo==0?"GRAFO":"DIGRAFO",g.nVertices);
    for (i=0; i <g.nVertices; i++)
    {
        for (j=0; j < g.nVertices; j++)
            printf ("%0.1f   ", PesoDaAresta (g, i, j));
        printf ("\n");
    }
    printf ("\n");
}


int main (){
    int n, dig, i;
    Grafo g;
    int origem = 0;
    int destino = 2; // opcional
    int grafoConexo = 0;
    ListaDeVertices caminho;


    // grafo do PPT
    n = 12;
    dig = 0;
    CriarGrafo (&g, n, dig);
    InserirAresta (&g, 0, 1, 1);
    InserirAresta (&g, 0, 2, 1);
    InserirAresta (&g, 0, 3, 1);
    InserirAresta (&g, 1, 4, 1);
    InserirAresta (&g, 1, 5, 1);
    InserirAresta (&g, 2, 5, 1);
    InserirAresta (&g, 3, 6, 1);
    InserirAresta (&g, 3, 7, 1);
    InserirAresta (&g, 4, 8, 1);
    InserirAresta (&g, 4, 9, 1);
    InserirAresta (&g, 6, 7, 1);
    InserirAresta (&g, 8, 9, 1);
    InserirAresta (&g, 10, 11, 1);
    ExibirGrafo (g);


    printf ("Busca em profundidade: \n");
    DFS(g, origem, destino, &caminho);
    for (i=0; i < caminho.nVertices; i++)
        printf("%c    ",caminho.vertices[i]+65);
    printf ("\n\n");


    printf ("Busca em largura: \n");
    float dist[g.nVertices];
    BFS(g, origem, destino, dist, &caminho);
    for (i=0; i < g.nVertices; i++)
        if (dist[i] != INFINITY)
            printf("%c: %5.2f\n",caminho.vertices[i]+65,dist[i]);
        else{
            printf("%c:  +inf\n",caminho.vertices[i]+65);
            grafoConexo++;
        }
    if (grafoConexo != 0)
        printf("Grafo Nao Conexo\n");
    else
        printf("Grafo Conexo\n");

    return 0;
}
